rootProject.name = "NewProjectCI"
